// Get elements
const decreaseButton = document.querySelector('.decrease-quantity');
const increaseButton = document.querySelector('.increase-quantity');
const quantityInput = document.querySelector('.quantity');
const addToCartButton = document.querySelector('.add-to-cart');

// Add event listeners
decreaseButton.addEventListener('click', decreaseQuantity);
increaseButton.addEventListener('click', increaseQuantity);
addToCartButton.addEventListener('click', addToCart);

function decreaseQuantity() {
    let currentValue = parseInt(quantityInput.value);
    if (currentValue > 1) {
        quantityInput.value = currentValue - 1;
    }
}

function increaseQuantity() {
    let currentValue = parseInt(quantityInput.value);
    quantityInput.value = currentValue + 1;
}

function addToCart() {
    let productTitle = document.querySelector('.product-title').innerText;
    let productPrice = document.querySelector('.product-price').innerText;
    let quantity = quantityInput.value;
    console.log(`Adding ${quantity} of ${productTitle} at ${productPrice} each to cart.`);
}
let shippingInfo = {};

document.getElementById('customerName').addEventListener('change', (event) => {
  shippingInfo.customerName = event.target.value;
});

// Repeat for other fields

function sendDataToServer() {
  fetch('/api/saveShippingInfo', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(shippingInfo),
  })
  .catch((error) => {
    console.error('Error:', error);
  });
}

// Call sendDataToServer function whenever a form field changes
document.getElementById('customerName').addEventListener('change', sendDataToServer);
// Repeat for other fields
