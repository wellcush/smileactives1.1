// Import express
const express = require('express');

// Import cors
const cors = require('cors');

// Import fs (file system) module to write data to file
const fs = require('fs');

// Create a new express application instance
const app = express();

// Enable All CORS Requests
app.use(cors());

// The port the express app will listen on
const port = 4000;

// Use JSON parser for all requests
app.use(express.json());

// Endpoint to save the shipping info
app.post('/api/saveShippingInfo', function (req, res) {
  console.log(req.body); // Logs to your server console

  // read existing data from the file
  fs.readFile('data.json', 'utf8', (err, data) => {
    if (err) {
        console.error(err);
        return;
    }
    
    let existingData = data ? JSON.parse(data) : [];

    // append new data to existing data
    existingData.push(req.body);

    // write the updated data back to the file
    fs.writeFile('data.json', JSON.stringify(existingData, null, 2), (err) => {
      if (err) {
        console.error(err);
        return;
      }
      console.log('Data written to file');
    });
  });

  res.json({ status: 'received' }); // Responds to the client
});



// Serve static files from the 'public' directory
app.use(express.static('public'));

// Start listening on the specified port
app.listen(port, () => {
  console.log('Server is running on port', port);
});
